name = "zzdlab"
version = "0.1.3"

from zzd.utils.scores import scores
from zzd.methods.interolog import interolog



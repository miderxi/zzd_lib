name = "zzdlab"

from scores import scores



"""
test_ppi.txt train_ppi.txt 
encode:ac, dpc, ct, cksaap, ara2vec, dmi2vec, esm ,pdb2dpc

python RF.py -test=test.txt -train=train.txt -encode="ac,ct,cksaap,..." -out=/tmp/rf.txt

"""



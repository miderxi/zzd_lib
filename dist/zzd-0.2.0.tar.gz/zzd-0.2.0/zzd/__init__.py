name = "zzdlab"
version = "0.1"
from zzd.utils.assess import multi_scores as scores
from zzd.feature_encode import  encodes
from zzd.methods.interolog  import interolog
from zzd.methods.ppi_randomforest import ppi_randomforest





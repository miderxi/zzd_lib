This is a commone tool function lib.


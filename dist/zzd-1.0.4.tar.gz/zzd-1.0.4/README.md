
# install
pip install zzd

$$E = MC^2$$





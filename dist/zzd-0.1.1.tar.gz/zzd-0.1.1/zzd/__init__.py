name = "zzdlab"
from zzd.utils.scores import scores



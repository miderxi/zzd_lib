from zzd.methods.interolog import interolog
from zzd.methods.ppi_randomforest import ppi_randomforest


#import numpy as np
#from zzd.feature_encode.ac import ac
#from zzd.feature_encode.dpc import dpc
#from zzd.feature_encode.cksaap import cksaap
#from zzd.feature_encode.ct import ct
#from zzd.feature_encode.pdb2graph import pdb2graph
#



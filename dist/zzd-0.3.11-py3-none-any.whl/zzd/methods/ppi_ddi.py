














def ppi_ddi():
    """
    protein-protein interaction prediction of domain-domain interaction.
    """
    






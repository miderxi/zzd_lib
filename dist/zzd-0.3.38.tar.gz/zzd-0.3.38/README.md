# install
pip install zzd



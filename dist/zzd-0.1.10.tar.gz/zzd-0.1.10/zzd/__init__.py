name = "zzdlab"
version = "0.1.3"

#method to predict ppi interaction
from zzd.methods.interolog import interolog

#encode function
from zzd.utils.scores import scores
#from zzd.utils.encode import encode


name = "zzdlab"

from zzd.scores import scores


